from django.contrib import admin
from delivery.models import PlantationDelivery

# Register your models here.

admin.site.register(PlantationDelivery)