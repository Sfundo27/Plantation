from django.contrib import admin
from rentals.models import PlantationRentalModel

# Register your models here.

admin.site.register(PlantationRentalModel)