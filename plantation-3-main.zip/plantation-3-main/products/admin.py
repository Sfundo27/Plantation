from django.contrib import admin
from products.models import PlantationProduct

# Register your models here.
admin.site.register(PlantationProduct)