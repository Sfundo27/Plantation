# from django import forms
# from notifications.models import PlantationMessageNotification, PlantationNotificationStatus

# class PlantationMessageNotificationForm(forms.ModelForm):
#     class Meta:
#         model = PlantationMessageNotification
#         fields = "__all__"
  
# class PlantationNotificationStatusForm(forms.ModelForm):
#     class Meta:
#         model = PlantationNotificationStatus
#         fields = "__all__"


