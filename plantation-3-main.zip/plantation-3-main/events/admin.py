from django.contrib import admin
from events.models import PlantationEventModel
# Register your models here.

# admin.site.register(PlantationTiketModel)
admin.site.register(PlantationEventModel)