from django.contrib import admin
from user.models import PlantationUser
# Register your models here.

admin.site.register(PlantationUser)