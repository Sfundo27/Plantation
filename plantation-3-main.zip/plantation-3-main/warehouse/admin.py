from django.contrib import admin
from warehouse.models import PlantationWarehouse

# Register your models here.
admin.site.register(PlantationWarehouse)